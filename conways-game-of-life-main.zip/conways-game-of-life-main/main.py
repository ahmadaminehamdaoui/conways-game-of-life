# to-do: déplacement en restant appuyé

from tkinter import Grid
import pygame, sys, ctypes
from pygame.constants import K_F1, K_F2, K_F9, K_PLUS, K_MINUS
from classes import *

user32 = ctypes.windll.user32
width, height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

# setup
pygame.init()
pygame.display.init()
pygame.display.set_caption('Level Editor')
clock = pygame.time.Clock()
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)

# level
offset = [0,0]
future_grid = []

line = []
for y in range(level.height):
    for x in range(level.width):
        line.append(0)
    level.grid.append(line)
    line = []

game_timer = 0

# ui
moving = {'left':0,'right':0,'up':0,'down':0}
clicking = {'left':0,'right':0}
labels = []
display = {'dev':False}

# functions
def update_cell(x, y):
    global future_grid
    counter = 0
    for x_ in range (-1,2):
        for y_ in range (-1,2):
            if not(x_==0 and y_==0):
                if y+y_ < level.height and x+x_ < level.width:
                    if level.grid[y+y_][x+x_]==1: counter += 1

    if counter > 0 and display['dev']:
        color = False if level.grid[y][x]==1 else True
        labels.append(Label(Vec2(x*level.tile_size, y*level.tile_size), str(counter), centered = False, black=color))

    if counter == 3:
        future_grid[y][x] = 1
    elif counter == 2:
        if level.grid[y][x] == 1: future_grid[y][x] = 1

while True:
    # --- frame refresh
    screen.fill((0,0,0))
    current_fps = round(clock.get_fps())
    mouse = pygame.mouse.get_pos()
    future_grid = []
    line = []
    for y in range(level.height):
        for x in range(level.width):
            line.append(0)
        future_grid.append(line)
        line = []

    # --- game
    # drawing
    if clicking['left'] or clicking['right']:
        level.grid[int(mouse[1]//level.tile_size)+offset[1] if int(mouse[1]//level.tile_size)+offset[1]<level.height else level.height-1][int(mouse[0]//level.tile_size)+offset[0] if int(mouse[0]//level.tile_size)+offset[0]<level.height else level.width-1] = 1 if clicking['left'] else 0

    # neighbors
    for y in range(level.height):
        for x in range(level.width):
            update_cell(x,y)

    # update
    if not level.playing:
        game_timer = 0
        level.updateFrame = False

    if level.updateFrame:
        level.grid = future_grid
        level.updateFrame = False
        game_timer += 1

    elif game_timer > 0:
        game_timer += 1
        if game_timer >= clock.get_fps()/(4*level.speed):
            level.updateFrame = True
            game_timer = 0

    # --- events handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1: clicking['left'] = True
            elif event.button == 3: clicking['right'] = True

            # molette
            if event.button == 4 :
                level.tile_size += 5
            if event.button == 5 :
                if level.tile_size>5: level.tile_size -= 5

            # camera
            if moving["up"]: offset[1] -= 5
            elif moving["down"]: offset[1] += 5
            elif moving["left"]: offset[0] -= 5
            elif moving["right"]: offset[0] += 5

        elif event.type == pygame.MOUSEBUTTONUP:
            clicking = {'left':0,'right':0}

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                moving["up"] = 1
                offset[1]-=5
            elif event.key == pygame.K_DOWN:
                moving["down"] = 1
                offset[1]+=5
            elif event.key == pygame.K_LEFT:
                moving["left"] = 1
                offset[0]-=5
            elif event.key == pygame.K_RIGHT:
                moving["right"] = 1
                offset[0]+=5

        elif event.type == pygame.KEYUP:
            if event.key == pygame.K_UP:
                moving["up"] = 0
            elif event.key == pygame.K_DOWN:
                moving["down"] = 0
            elif event.key == pygame.K_LEFT:
                moving["left"] = 0
            elif event.key == pygame.K_RIGHT:
                moving["right"] = 0

            elif event.key == pygame.K_1:
                level.grid = []
                line = []
                for y in range(level.height):
                    for x in range(level.width):
                        line.append(0)
                    level.grid.append(line)
                    line = []
            elif event.key == pygame.K_0:
                pygame.quit()
                sys.exit()

            elif event.key == pygame.K_RETURN:
                level.playing = not level.playing
                level.updateFrame = True

            elif event.key == pygame.K_2:
                if level.speed > 0.5:
                    level.speed = round(level.speed-0.5, 1)

            elif event.key == pygame.K_3:
                level.speed = round(level.speed+0.5, 1)

    # --- ui
    if display['dev']:
        labels.append(Label(Vec2(0,0), 'FPS: '+str(current_fps), centered = False, black=True))

    # --- drawing
    # map
    for y in range(level.height):
        for x in range(level.width):
            color = (255,255,255) if level.grid[y][x]==0 else (0,0,0)
            pygame.draw.rect(screen, color, pygame.Rect((x-offset[0])*level.tile_size, (y-offset[1])*level.tile_size, level.tile_size, level.tile_size))
    # mouse overlay
    pygame.draw.rect(screen, (0,0,0), pygame.Rect(int((mouse[0])//level.tile_size*level.tile_size), int((mouse[1])//level.tile_size*level.tile_size), level.tile_size, level.tile_size),1)
    # ui
    for label in labels:
        label.draw(screen, label.text)

    ui = [Label(Vec2(20, height-260), '(MOUSE LEFT) Place', centered = False, black=False),
          Label(Vec2(20, height-235), '(MOUSE RIGHT) Erase', centered = False, black=False),
          Label(Vec2(20, height-185), '(WHEEL) Zoom', centered = False, black=False),
          Label(Vec2(20, height-160), '(ARR. KEYS) Move Camera', centered = False, black=False),
          Label(Vec2(20, height-115), '(0) Exit', centered = False, black=False),
          Label(Vec2(20, height-90), '(1) Clear stage ', centered = False, black=False),
          Label(Vec2(20, height-65), '(2 AND 3) Game speed '+str(level.speed)+'x', centered = False, black=False),
          Label(Vec2(20, height-40), '(RETURN) Pause' if level.playing else '(RETURN) Play', centered = False, black=False)]
    pygame.draw.rect(screen, (0,0,0), pygame.Rect(0, height-270, 270, 585))
    for lab in ui:
        lab.draw(screen, lab.text)

    # --- update
    pygame.display.update()
    clock.tick(60)