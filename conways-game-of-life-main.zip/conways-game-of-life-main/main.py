from tkinter import Grid
import pygame, sys, ctypes
from pygame.constants import K_F1, K_F2, K_F9, K_PLUS, K_MINUS
from classes import *

user32 = ctypes.windll.user32
width, height = user32.GetSystemMetrics(0), user32.GetSystemMetrics(1)

# setup
pygame.init()
pygame.display.init()
pygame.display.set_caption('Level Editor')
clock = pygame.time.Clock()
screen = pygame.display.set_mode((0,0), pygame.FULLSCREEN)

# level
future_grid = []

line = []
for y in range(level.height):
    for x in range(level.width):
        line.append(0)
    level.grid.append(line)
    line = []

game_timer = 0

# ui
clicking = {'left':0,'right':0}
labels = []
display = {'dev':False}

# functions
def update_cell(x, y):
    global future_grid
    counter = 0
    for x_ in range (-1,2):
        for y_ in range (-1,2):
            if not(x_==0 and y_==0):
                if y+y_ < level.height and x+x_ < level.width:
                    if level.grid[y+y_][x+x_]==1: counter += 1

    if counter > 0 and display['dev']:
        color = False if level.grid[y][x]==1 else True
        labels.append(Label(Vec2(origin[0]+x*level.tile_size, origin[1]+y*level.tile_size), str(counter), centered = False, black=color))

    if counter == 3:
        print(len(future_grid), len(future_grid[0]))
        print(level.height, level.width)
        print(y, x)
        future_grid[y][x] = 1
    elif counter == 2:
        if level.grid[y][x] == 1: future_grid[y][x] = 1


while True:
    # --- frame refresh
    screen.fill((0,0,0))
    current_fps = round(clock.get_fps())
    mouse = pygame.mouse.get_pos()

    labels = []

    future_grid = []
    line = []
    for y in range(level.height):
        for x in range(level.width):
            line.append(0)
        future_grid.append(line)
        line = []

    # --- game
    # drawing
    origin = [int(width/2-(level.tile_size*level.width)/2), int(height/2-(level.tile_size*level.height)/2)]
    if clicking['left'] or clicking['right']:
        print(int((mouse[1]-origin[1])*level.tile_size))
        level.grid[int((mouse[1]-origin[1])//level.tile_size)][int((mouse[0]-origin[0])//level.tile_size)] = 1 if clicking['left'] else 0

    # neighbors
    for y in range(level.height):
        for x in range(level.width):
            update_cell(x,y)

    # update
    if not level.playing:
        game_timer = 0
        level.updateFrame = False

    if level.updateFrame:
        level.grid = future_grid
        level.updateFrame = False
        game_timer += 1

    elif game_timer > 0:
        game_timer += 1
        if game_timer >= clock.get_fps()/(4*level.speed):
            level.updateFrame = True
            game_timer = 0

    # --- events handler
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1: clicking['left'] = True
            elif event.button == 3: clicking['right'] = True

        elif event.type == pygame.MOUSEBUTTONUP:
            clicking = {'left':0,'right':0}

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_F1:
                display['dev'] = not display['dev']
            elif event.key == pygame.K_F2:
                level.grid = []
                line = []
                for y in range(level.height):
                    for x in range(level.width):
                        line.append(0)
                    level.grid.append(line)
                    line = []
            elif event.key == pygame.K_F9:
                pygame.quit()
                sys.exit()

            elif event.key == pygame.K_RETURN:
                print('ok')
                level.playing = not level.playing
                level.updateFrame = True

            elif event.key == pygame.K_1:
                if level.speed > 0.1:
                    level.speed = round(level.speed-0.1, 1)

            elif event.key == pygame.K_2:
                level.speed = round(level.speed+0.1, 1)

    # --- ui
    if display['dev']:
        labels.append(Label(Vec2(origin[0]+10, origin[1]+10), 'FPS: '+str(current_fps), centered = False))

    # --- drawing
    # map
    for y in range(level.height):
        for x in range(level.width):
            color = (255,255,255) if level.grid[y][x]==0 else (0,0,0)
            pygame.draw.rect(screen, color, pygame.Rect(origin[0]+x*level.tile_size, origin[1]+y*level.tile_size, level.tile_size, level.tile_size))
    # mouse overlay
    pygame.draw.rect(screen, (0,0,0), pygame.Rect(origin[0]+int((mouse[0]-origin[0])//level.tile_size*level.tile_size), origin[1]+int((mouse[1]-origin[1])//level.tile_size*level.tile_size), level.tile_size, level.tile_size),1)
    # ui
    for label in labels:
        label.draw(screen, label.text)

    ui = [Label(Vec2(20, height-90), '(F2) Clear stage ', centered = False, black=False),
          Label(Vec2(20, height-65), '(0 AND 1) Game speed '+str(level.speed)+'x', centered = False, black=False),
          Label(Vec2(20, height-40), '(RETURN) Pause' if level.playing else '(RETURN) Play', centered = False, black=False)]
    for lab in ui:
        lab.draw(screen, lab.text)

    # --- update
    pygame.display.update()
    clock.tick(60)